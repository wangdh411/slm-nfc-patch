#!/bin/bash

CRTDIR=$(pwd)
echo 'current dir' $CRTDIR

if [[ $1 = "update" ]]; then
    if [ ! -d "$CRTDIR/NFC_NCIHAL_Nfc/.git" ]; then
        git clone git@github.com:NXPNFCProject/NFC_NCIHAL_Nfc.git
    fi
    if [ ! -d "$CRTDIR/NFC_NCIHAL_base/.git" ]; then
        git clone git@github.com:NXPNFCProject/NFC_NCIHAL_base.git
    fi
    if [ ! -d "$CRTDIR/NFC_NCIHAL_docs/.git" ]; then
        git clone git@github.com:NXPNFCProject/NFC_NCIHAL_docs.git
    fi
    if [ ! -d "$CRTDIR/NFC_NCIHAL_libnfc-nci/.git" ]; then
        git clone git@github.com:NXPNFCProject/NFC_NCIHAL_libnfc-nci.git
    fi
    if [ ! -d "$CRTDIR/NXPNFC_Reference/.git" ]; then
        git clone git@github.com:NXPNFCProject/NXPNFC_Reference.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_frameworks/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_frameworks.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_keymaster_hidlimpl/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_keymaster_hidlimpl.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_keymint_hidlimpl/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_keymint_hidlimpl.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_nfc_hidlimpl/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_nfc_hidlimpl.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_nxp_ese_clients/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_nxp_ese_clients.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_se_hidlimpl/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_se_hidlimpl.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_secureelement/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_secureelement.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_weaver_hidlimpl/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_weaver_hidlimpl.git
    fi
fi

#br="br_android_ncihalx_comm_14"
#br="br_android_ncihalx_comm_13"
br="br_android_ncihalx_row_12"
#br="br_android_ncihalx_row_q"
zips="nxpnfc_"$br"_$(date +%Y%m%d-%H%M%S)"
tar cvf $zips.tar $0 

for dir in $(ls $CRTDIR); do
	if [ -d "$CRTDIR/$dir" ];then
        cd $CRTDIR/$dir;
        echo 'Entry ' $CRTDIR/$dir
        target=$dir
        git checkout $br 
        if [ $? -eq 0 ]; then
		    git reset --hard;
        else
            target=''
            echo "the branch $br is not contain folder $dir"
        fi
		cd ../;
        if [ "$target" = "$dir" ]; then
            echo 'package' $dir
            tar rvf $zips.tar --exclude=$dir/.git $dir
        fi
	fi
done
gzip $zips.tar

