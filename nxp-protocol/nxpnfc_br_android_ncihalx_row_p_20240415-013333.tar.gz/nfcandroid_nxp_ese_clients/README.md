# nfcandroid_nxp_ese_clients

This Repo contains any additional information/files required to support the release

####Git Repository

| DESCRIPTION        | CHECKOUT COMMAND          |
| :-------------: |:-------------:| 
| NXPNFC_Reference    |  git clone https://github.com/NXPNFCProject/NXPNFC_Reference.git |


####Supported Versions on "br_android_ncihalx_row_p" Branch

| Android Version        | NXP Release          | NXP Tag  |
| :-------------: |:-------------:| :-----:|
| android-9.0.0_r3              |  9.6.0 (PN80T/PN81T) |  NFC_NCIHALx_AR18C0.9.6.0_OpnSrc |
