# nfcandroid_weaver_hidlimpl

#### Git Repository

| DESCRIPTION        | CHECKOUT COMMAND          |
| :-------------: |:-------------:| 
| NFC_NCIHAL_docs    |  git clone git@github.com:NXPNFCProject/nfcandroid_weaver_hidlimpl.git |



#### Supported Version on "br_android_ncihalx_comm_15" branch
| Android Version        | NXP Release          | NXP Tag  |
| :-------------: |:---------------------:| :-----:|
| aosp-main              |  15.02.00 (PN557/PN560/SN100/SN110/SN220) |  NFC_AR_00_3E800_15.02.00_OpnSrc |











