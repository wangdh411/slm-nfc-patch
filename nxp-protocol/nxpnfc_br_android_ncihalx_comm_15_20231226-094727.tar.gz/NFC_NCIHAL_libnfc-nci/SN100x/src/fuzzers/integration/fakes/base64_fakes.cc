#include <stdlib.h>

extern "C" void __b64_ntop() { abort(); }
