# NFCNCIHAL_base

#### Git Repository

| DESCRIPTION        | CHECKOUT COMMAND          |
| :-------------: |:-------------:| 
| NFCNCIHAL_base    |  git clone https://github.com/NXPNFCProject/NFC_NCIHAL_base.git |

#### Supported Version on "br_android_ncihalx_comm_15" branch
| Android Version        | NXP Release          | NXP Tag  |
| :-------------: |:---------------------:| :-----:|
| aosp-main              |  15.02.00 (PN557/PN560/SN100/SN110/SN220) |  NFC_AR_00_3E800_15.02.00_OpnSrc |












