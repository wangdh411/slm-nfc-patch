# nfcandroid_keymint_hidlimpl
#
#### Git Repository

| DESCRIPTION        | CHECKOUT COMMAND          |
| :-------------: |:-------------:| 
| nfcandroid_keymint_hidlimpl   |  git clone https://github.com/NXPNFCProject/nfcandroid_keymint_hidlimpl.git |

#### Supported Version on "br_android_ncihalx_comm_13" branch
| Android Version        | NXP Release          | NXP Tag  |
| :-------------: |:---------------------:| :-----:|
| aosp-master            |  13.02.01 (SN100/SN110/SN220) |  NFC_AR_00_E800_13.02.01_OpnSrc |
| aosp-master              |  13.03.00 (SN100/SN110/SN220) |  NFC_AR_00_E800_13.03.00_OpnSrc |
| android-13-preview-1              |  13.09.00 (PN557/PN560/SN100/SN110/SN220) |  NFC_AR_00_1E800_13.09.00_OpnSrc |
| android-13.0.0_r3              |  13.0B.00 (PN557/PN560/SN100/SN110/SN220) |  NFC_AR_00_1E800_13.0B.00_OpnSrc |
| android-13.0.0_r3              |  13.0D.01 (PN557/PN560/SN100/SN110/SN220) |  NFC_AR_00_1E800_13.0D.01_OpnSrc |














