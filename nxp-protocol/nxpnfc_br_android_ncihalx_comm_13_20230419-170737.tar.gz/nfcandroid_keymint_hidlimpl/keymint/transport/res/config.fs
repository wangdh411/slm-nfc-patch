[AID_VENDOR_NXP_STRONGBOX]
value:2901

[AID_VENDOR_NXP_WEAVER]
value:2902


[vendor/bin/hw/android.hardware.security.keymint-service.strongbox]
mode: 0755
user: AID_VENDOR_NXP_STRONGBOX
group: AID_SYSTEM
caps: SYS_ADMIN SYS_NICE

[vendor/bin/hw/android.hardware.weaver@1.0-service]
mode: 0755
user: AID_VENDOR_NXP_WEAVER
group: AID_SYSTEM
caps: SYS_ADMIN SYS_NICE
