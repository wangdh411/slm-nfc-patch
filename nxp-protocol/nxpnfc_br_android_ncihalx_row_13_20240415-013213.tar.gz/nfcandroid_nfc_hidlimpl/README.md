# nfcandroid_nfc_hidlimpl

#### Git Repository

| DESCRIPTION        | CHECKOUT COMMAND          |
| :-------------: |:-------------:| 
| nfcandroid_nfc_hidlimpl    |  git clone https://github.com/NXPNFCProject/nfcandroid_nfc_hidlimpl.git |



#### Supported Version on "br_android_ncihalx_row_13" branch
| Android Version        | NXP Release          | NXP Tag  |
| :-------------: |:---------------------:| :-----:|
| android-13-preview-1              |  13.01.00 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_13.01.00_OpnSrc |
| android-13.0.0_r3              |  13.02.00 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_13.02.00_OpnSrc |






#### Supported Version on "br_android_ncihalx_row_12" branch
| Android Version        | NXP Release          | NXP Tag  |
| :-------------: |:---------------------:| :-----:|
| aosp-master                |  12.01.00 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_12.01.00_OpnSrc  |
| android-12.0.0_r2              |  12.02.00 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_12.02.00_OpnSrc |






#### Supported Version on "br_android_ncihalx_row_11" branch
| Android Version        | NXP Release          | NXP Tag  |
| :-------------: |:---------------------:| :-----:|
| aosp-master                |  11.01.00 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_11.01.00_OpnSrc  |
| aosp-master              |  11.01.01 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_11.01.01_OpnSrc |
| android-11.0.0_r3              |  11.02.00 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_11.02.00_OpnSrc |
| android-11.0.0_r3              |  11.03.00 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_11.03.00_OpnSrc |






#### Supported Version on "br_android_ncihalx_row_q" branch
| Android Version        | NXP Release          | NXP Tag  |
| :-------------: |:---------------------:| :-----:|
| aosp-master                |  10.01.00 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_10.01.00_OpnSrc  |
| aosp-master              |  10.02.00 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_10.02.00_OpnSrc |
| android-10.0.0_r2              |  10.03.00 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_10.03.00_OpnSrc |
| android-10.0.0_r2              |  10.04.00 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_10.04.00_OpnSrc |






#### Supported Versions on "br_android_ncihalx_row_p" Branch

| Android Version        | NXP Release          | NXP Tag  |
| :-------------: |:-------------:| :-----:|
| android-p-preview 2               |  9.0.D (PN553) |  NFC_NCIHALx_AR00C0.9.0.D_OpnSrc |
| android-9.0.0_r3              |  9.1.0 (PN557) |  NFC_NCIHALx_AR0800.9.1.0_OpnSrc |
| android-9.0.0_r3              |  9.2.0 (PN81T/PN557) |  NFC_NCIHALx_AR1800.9.2.0_OpnSrc |
| android-9.0.0_r3               |  9.3.0 (PN553) |  NFC_NCIHALx_AR0040.9.3.0_OpnSrc |
| android-9.0.0_r3              |  9.4.0 (PN553) |  NFC_NCIHALx_AR00C0.9.4.0_OpnSrc |
| android-9.0.0_r3              |  9.5.0 (PN557) |  NFC_NCIHALx_AR1800.9.5.0_OpnSrc |
| android-9.0.0_r3              |  9.6.0 (PN80T/PN81T) |  NFC_NCIHALx_AR18C0.9.6.0_OpnSrc |



