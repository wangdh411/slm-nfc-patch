# nfcandroid_nxp_ese_clients

#### Supported Version on "br_android_ncihalx_row_q" branch
| Android Version        | NXP Release          | NXP Tag  |
| :-------------: |:---------------------:| :-----:|
| aosp-master                |  10.01.00 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_10.01.00_OpnSrc  |
| aosp-master              |  10.02.00 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_10.02.00_OpnSrc |
| android-10.0.0_r2              |  10.03.00 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_10.03.00_OpnSrc |
| android-10.0.0_r2              |  10.04.00 (PN80T/PN81T/PN553/PN557) |  NFC_AR_00_18C0_10.04.00_OpnSrc |










