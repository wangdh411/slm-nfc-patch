#include <stdint.h>

namespace android {
namespace util {
void stats_write(int32_t, ...) {}
}  // namespace util
}  // namespace android
