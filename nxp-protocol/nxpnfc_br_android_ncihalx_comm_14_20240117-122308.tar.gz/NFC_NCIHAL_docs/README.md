# NFC_NCIHAL_docs


#### Git Repository

| DESCRIPTION        | CHECKOUT COMMAND          |
| :-------------: |:-------------:| 
| NFC_NCIHAL_docs    |  git clone https://github.com/NXPNFCProject/NFC_NCIHAL_docs.git |

#### Supported Version on "br_android_ncihalx_comm_14" branch
| Android Version        | NXP Release          | NXP Tag  |
| :-------------: |:---------------------:| :-----:|
| aosp-master      |  14.02.00 (PN557/PN560/SN100/SN110/SN220) |  NFC_AR_00_1E800_14.02.00_OpnSrc |
| aosp-master              |  14.03.00 (PN557/PN560/SN100/SN110/SN220) |  NFC_AR_00_1E800_14.03.00_OpnSrc |
| aosp-master              |  14.04.00 (PN557/PN560/SN100/SN110/SN220) |  NFC_AR_00_1E800_14.04.00_OpnSrc |
| aosp-master              |  14.05.00 (PN557/PN560/SN100/SN110/SN220) |  NFC_AR_00_1E800_14.05.00_OpnSrc |
| aosp-master              |  14.05.00 (PN557/PN560/SN100/SN110/SN220) |  NFC_AR_00_1E800_14.05.00_OpnSrc |
| aosp-master              |  14.05.00 (PN557/PN560/SN100/SN110/SN220) |  NFC_AR_00_1E800_14.05.00_OpnSrc |
| aosp-master              |  14.08.00 (PN557/PN560/SN100/SN110/SN220) |  NFC_AR_00_3E800_14.08.00_OpnSrc |
| aosp-master              |  14.0B.00 (PN557/PN560/SN100/SN110/SN220) |  NFC_AR_00_3E800_14.0B.00_OpnSrc |
| android-14.0.0_r2        |  14.0E.00 (PN557/PN560/SN100/SN110/SN220) |  NFC_AR_00_3E800_14.0E.00_OpnSrc |








