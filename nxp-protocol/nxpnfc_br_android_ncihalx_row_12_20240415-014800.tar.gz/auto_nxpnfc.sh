#!/bin/bash

function git-branch-name {
	git symbolic-ref HEAD 2>/dev/null | cut -d"/" -f 3
}

function git-branch-prompt {
	local branch=`git-branch-name`
	if [ $branch ]; then echo $branch; fi
}

function clone-nxp-nfc {
    if [ ! -d "$CRTDIR/NFC_NCIHAL_Nfc/.git" ]; then
        git clone git@github.com:NXPNFCProject/NFC_NCIHAL_Nfc.git
    fi
    if [ ! -d "$CRTDIR/NFC_NCIHAL_base/.git" ]; then
        git clone git@github.com:NXPNFCProject/NFC_NCIHAL_base.git
    fi
    if [ ! -d "$CRTDIR/NFC_NCIHAL_docs/.git" ]; then
        git clone git@github.com:NXPNFCProject/NFC_NCIHAL_docs.git
    fi
    if [ ! -d "$CRTDIR/NFC_NCIHAL_libnfc-nci/.git" ]; then
        git clone git@github.com:NXPNFCProject/NFC_NCIHAL_libnfc-nci.git
    fi
    if [ ! -d "$CRTDIR/NXPNFC_Reference/.git" ]; then
        git clone git@github.com:NXPNFCProject/NXPNFC_Reference.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_frameworks/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_frameworks.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_keymaster_hidlimpl/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_keymaster_hidlimpl.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_keymint_hidlimpl/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_keymint_hidlimpl.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_nfc_hidlimpl/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_nfc_hidlimpl.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_nxp_ese_clients/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_nxp_ese_clients.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_se_hidlimpl/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_se_hidlimpl.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_secureelement/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_secureelement.git
    fi
    if [ ! -d "$CRTDIR/nfcandroid_weaver_hidlimpl/.git" ]; then
        git clone git@github.com:NXPNFCProject/nfcandroid_weaver_hidlimpl.git
    fi
}

CRTDIR=$(pwd)
echo 'current dir' $CRTDIR

if [[ $1 = "update" ]]; then
	$(clone-nxp-nfc)
fi

pkgs=0
if [[ $1 = "tar" || $2 = "tar" || $3 = "tar" ]]; then
	pkgs=1
fi

cd "$CRTDIR/NFC_NCIHAL_docs"
echo "Current branch: " $(git-branch-prompt)
cd $CRTDIR

#br="master"
#br="br_android_ncihalx_comm_15"
#br="br_android_ncihalx_comm_14"
#br="br_android_ncihalx_comm_13"
#br="br_android_ncihalx_row_13"
br="br_android_ncihalx_row_12"
#br="br_android_ncihalx_row_11"
#br="br_android_ncihalx_row_q"
#br="br_android_ncihalx_row_p"
#br="br_android_ncihalx_o"

if [ $pkgs = 1 ]; then
	zips="nxpnfc_"$br"_$(date +%Y%m%d-%H%M%S)"
    tar cvf $zips.tar $0
fi

for dir in $(ls $CRTDIR); do
	if [ -d "$CRTDIR/$dir" ];then
        cd $CRTDIR/$dir;
        echo 'Entry ' $CRTDIR/$dir
        target=$dir
		if [[ $1 = "update" ]]; then
			git pull
		fi
        git checkout $br 
        if [ $? -eq 0 ]; then
		    git reset --hard;
        else
            target=''
            echo "the branch $br is not contain folder $dir"
        fi
		cd ../;
		if [ $pkgs = 1 ]; then
			if [ "$target" = "$dir" ]; then
                if [ "$target" = "NFC_NCIHAL_docs" ]; then
					echo 'package doc file only'
					tar rvf $zips.tar --exclude=$dir/.git $dir/*.pdf
					tar rvf $zips.tar --exclude=$dir/.git $dir/*.md
				else
					echo 'package' $dir
					tar rvf $zips.tar --exclude=$dir/.git $dir
				fi
			fi
		fi
	fi
done

if [ $pkgs = 1 ]; then
	gzip $zips.tar
fi

